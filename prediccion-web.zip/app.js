const API_BASE = "";

async function predecirHandler() {
  const valorActualStr = document.getElementById("valorActual").value.trim();
  const tendenciaStr = document.getElementById("tendencia").value.trim();
  const diasStr = document.getElementById("dias").value.trim();
  const salida = document.getElementById("predResultado");

  const valorActual = parseFloat(valorActualStr);
  const tendencia = parseFloat(tendenciaStr);
  const dias = diasStr === "" ? 1 : parseInt(diasStr, 10);

  if (Number.isNaN(valorActual) || Number.isNaN(tendencia) || Number.isNaN(dias)) {
    salida.textContent = "Ingresa valores numéricos válidos para la predicción.";
    return;
  }

  salida.textContent = "Calculando predicción...";

  try {
    const resp = await fetch(`${API_BASE}/api/prediccion/predecir`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ valorActual, tendencia, dias })
    });
    if (!resp.ok) {
      throw new Error(`Error ${resp.status}`);
    }
    const data = await resp.json();
    salida.textContent = `Predicción: ${data.prediccion} (riesgo: ${data.riesgo}). ${data.recomendacion}`;
  } catch (e) {
    console.error(e);
    salida.textContent =
      "No se pudo contactar al backend de predicción. Verifica que el servidor esté en ejecución.";
  }
}

function configurarNavegacionPred() {
  const botones = Array.from(document.querySelectorAll(".nav-btn"));
  const secciones = {
    inicio: document.getElementById("pred-sec-inicio"),
    modelo: document.getElementById("pred-sec-modelo"),
    resultados: document.getElementById("pred-sec-resultados"),
    historial: document.getElementById("pred-sec-historial")
  };

  function mostrarSeccion(nombre) {
    Object.keys(secciones).forEach((clave) => {
      const s = secciones[clave];
      if (!s) return;
      if (clave === nombre) {
        s.classList.add("section-visible");
      } else {
        s.classList.remove("section-visible");
      }
    });
    botones.forEach((b) => {
      if (b.dataset.section === nombre) {
        b.classList.add("nav-btn-active");
      } else {
        b.classList.remove("nav-btn-active");
      }
    });
  }

  botones.forEach((b) => {
    b.addEventListener("click", () => {
      const nombre = b.dataset.section;
      mostrarSeccion(nombre);
    });
  });

  mostrarSeccion("inicio");
}

window.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("btnPredecir");
  if (btn) {
    btn.addEventListener("click", predecirHandler);
  }
  configurarNavegacionPred();

  const toggle = document.getElementById("predChatToggle");
  const panel = document.getElementById("predChatPanel");
  const close = document.getElementById("predChatClose");
  const send = document.getElementById("predChatSend");
  const input = document.getElementById("predChatInput");

  function togglePanel() {
    if (!panel) return;
    panel.classList.toggle("chatbot-panel-visible");
    if (panel.classList.contains("chatbot-panel-visible") && input) {
      input.focus();
    }
  }

  if (toggle) {
    toggle.addEventListener("click", togglePanel);
  }
  if (close) {
    close.addEventListener("click", togglePanel);
  }
  if (send && input) {
    send.addEventListener("click", () => {
      const texto = input.value.trim();
      if (!texto) return;
      enviarMensajePredBot(texto);
      input.value = "";
      input.focus();
    });
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        send.click();
      }
    });
  }

  inicializarPredBot();
});

const PREDBOT_STORAGE_KEY = "predbot_historial";

function agregarMensajePredBot(tipo, contenido) {
  const contenedor = document.getElementById("predChatMessages");
  if (!contenedor) return;
  const div = document.createElement("div");
  div.classList.add("chatbot-msg");
  if (tipo === "usuario") {
    div.classList.add("chatbot-msg-user");
  } else {
    div.classList.add("chatbot-msg-bot");
  }
  div.textContent = contenido;
  contenedor.appendChild(div);
  contenedor.scrollTop = contenedor.scrollHeight;

  const ahora = new Date().toISOString();
  const existente = JSON.parse(
    localStorage.getItem(PREDBOT_STORAGE_KEY) || "[]"
  );
  existente.push({ tipo, contenido, fecha_hora: ahora });
  localStorage.setItem(PREDBOT_STORAGE_KEY, JSON.stringify(existente));
}

function cargarHistorialPredBot() {
  const contenedor = document.getElementById("predChatMessages");
  if (!contenedor) return;
  contenedor.innerHTML = "";
  const existente = JSON.parse(
    localStorage.getItem(PREDBOT_STORAGE_KEY) || "[]"
  );
  existente.forEach((m) => {
    const div = document.createElement("div");
    div.classList.add("chatbot-msg");
    if (m.tipo === "usuario") {
      div.classList.add("chatbot-msg-user");
    } else {
      div.classList.add("chatbot-msg-bot");
    }
    div.textContent = m.contenido;
    contenedor.appendChild(div);
  });
  contenedor.scrollTop = contenedor.scrollHeight;
}

function respuestasPredefinidasPredBot(texto) {
  const t = texto.toLowerCase();
  if (t.includes("como funciona la prediccion")) {
    return "La predicción funciona combinando un valor actual, una tendencia por día y los días a proyectar. El modelo calcula una proyección y clasifica el riesgo como incremento, disminución o estabilidad.";
  }
  if (t.includes("que es la tendencia") || t.includes("tendencia")) {
    return "La tendencia indica cuánto se espera que cambie el valor cada día. Puede estimarse a partir de datos históricos o análisis previos.";
  }
  if (t.includes("interpretar") && t.includes("resultado")) {
    return "Para interpretar el resultado, compara la predicción con el valor actual. Si la predicción es mayor, hay incremento; si es menor, disminución; si es similar, estabilidad.";
  }
  if (t.includes("modelo") && t.includes("simple")) {
    return "Este modelo es lineal y educativo. En proyectos reales se usan técnicas más avanzadas, pero esta base ayuda a entender la lógica de las proyecciones.";
  }
  return null;
}

async function enviarMensajePredIA(mensajeUsuario) {
  const promptBase = `Eres un chatbot educativo de una app de predicción. Explicas cómo se usan las variables valorActual, tendencia y días, cómo se calcula la predicción y cómo interpretar los riesgos. No hablas de temas ajenos al proyecto ni de juegos de azar.
Mensaje del usuario: ${mensajeUsuario}`;

  try {
    const resp = await fetch(`${API_BASE}/api/prediccion/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: promptBase })
    });
    if (!resp.ok) {
      throw new Error(`Error ${resp.status}`);
    }
    const data = await resp.json();
    if (data && data.reply) {
      agregarMensajePredBot("bot", data.reply);
    } else {
      agregarMensajePredBot(
        "bot",
        "Por ahora solo tengo respuestas educativas básicas sobre la predicción."
      );
    }
  } catch (e) {
    console.error(e);
    agregarMensajePredBot(
      "bot",
      "No se pudo contactar al servicio de predicción en este momento. Intenta de nuevo más tarde."
    );
  }
}

async function enviarMensajePredBot(mensajeUsuario) {
  agregarMensajePredBot("usuario", mensajeUsuario);

  const rapida = respuestasPredefinidasPredBot(mensajeUsuario);
  if (rapida) {
    agregarMensajePredBot("bot", rapida);
    return;
  }

  await enviarMensajePredIA(mensajeUsuario);
}

function inicializarPredBot() {
  cargarHistorialPredBot();
}

