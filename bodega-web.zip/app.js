const API_BASE = "";

function actualizarPreview({ colegio, proteina, libras, kilos }) {
  const el = document.getElementById("previewEtiqueta");
  if (!el) return;
  el.querySelector(".etiqueta-colegio").textContent = colegio || "Colegio ejemplo";
  el.querySelector(".etiqueta-proteina").textContent =
    proteina || "Proteína ejemplo";
  const pesos = el.querySelector(".etiqueta-pesos");
  pesos.children[0].textContent = `Libras: ${libras ?? 0}`;
  pesos.children[1].textContent = `Kilos: ${kilos ?? 0}`;
}

async function calcularHandler() {
  const colegio = document.getElementById("colegio").value.trim();
  const proteina = document.getElementById("proteina").value.trim();
  const librasStr = document.getElementById("libras").value.trim();
  const decimalesStr = document.getElementById("decimales").value.trim();
  const resultadoEl = document.getElementById("resultado");

  const libras = parseFloat(librasStr);
  const decimales = decimalesStr === "" ? 2 : parseInt(decimalesStr, 10);

  if (Number.isNaN(libras)) {
    resultadoEl.textContent = "Ingresa un valor válido en libras.";
    return;
  }

  resultadoEl.textContent = "Calculando en el backend...";

  try {
    const resp = await fetch(`${API_BASE}/api/bodega/calcular`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ libras, decimales })
    });

    if (!resp.ok) {
      throw new Error(`Error ${resp.status}`);
    }

    const data = await resp.json();
    resultadoEl.textContent = `Resultado: ${data.libras} lb = ${data.kilos} kg (decimales: ${data.decimales})`;

    actualizarPreview({
      colegio,
      proteina,
      libras: data.libras,
      kilos: data.kilos
    });
  } catch (e) {
    console.error(e);
    resultadoEl.textContent =
      "No se pudo contactar al backend. Verifica que el servidor esté en http://localhost:4000";
  }
}

async function simularOCRHandler() {
  const salida = document.getElementById("ocrResultado");
  if (!salida) return;
  salida.textContent = "Simulando procesamiento de datos con OCR / Excel...";
  try {
    const resp = await fetch(`${API_BASE}/api/bodega/ocr`, { method: "POST" });
    if (!resp.ok) {
      throw new Error(`Error ${resp.status}`);
    }
    const data = await resp.json();
    if (Array.isArray(data.filas)) {
      const texto = data.filas
        .map(
          (f) =>
            `${f.colegio} - ${f.proteina} - ${f.libras} lb`
        )
        .join(" | ");
      salida.textContent = `Ejemplo de filas detectadas: ${texto}`;
    } else {
      salida.textContent = data.mensaje || "Procesamiento simulado completo.";
    }
  } catch (e) {
    console.error(e);
    salida.textContent =
      "No se pudo contactar al backend para la simulación de OCR / Excel.";
  }
}

function simularImpresionHandler() {
  const tamanoHoja = document.getElementById("tamanoHoja").value;
  const cuadritosPorHoja = document.getElementById("cuadritosPorHoja").value;
  const salida = document.getElementById("impresionResultado");
  if (!salida) return;
  salida.textContent = `Idea de impresión: hoja ${tamanoHoja} con ${cuadritosPorHoja} etiquetas por página. Más adelante se generará un PDF real.`;
}

function configurarNavegacion() {
  const botones = Array.from(document.querySelectorAll(".nav-btn"));
  const secciones = {
    inicio: document.getElementById("sec-inicio"),
    escanear: document.getElementById("sec-escanear"),
    diseno: document.getElementById("sec-diseno"),
    impresion: document.getElementById("sec-impresion"),
    historial: document.getElementById("sec-historial")
  };

  function mostrarSeccion(nombre) {
    Object.keys(secciones).forEach((clave) => {
      const s = secciones[clave];
      if (!s) return;
      if (clave === nombre) {
        s.classList.add("section-visible");
      } else {
        s.classList.remove("section-visible");
      }
    });
    botones.forEach((b) => {
      if (b.dataset.section === nombre) {
        b.classList.add("nav-btn-active");
      } else {
        b.classList.remove("nav-btn-active");
      }
    });
  }

  botones.forEach((b) => {
    b.addEventListener("click", () => {
      const nombre = b.dataset.section;
      mostrarSeccion(nombre);
    });
  });

  mostrarSeccion("inicio");
}

window.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("btnCalcular");
  if (btn) {
    btn.addEventListener("click", calcularHandler);
  }
  const btnSimularOCR = document.getElementById("btnSimularOCR");
  if (btnSimularOCR) {
    btnSimularOCR.addEventListener("click", simularOCRHandler);
  }
  const btnSimularImpresion = document.getElementById("btnSimularImpresion");
  if (btnSimularImpresion) {
    btnSimularImpresion.addEventListener("click", simularImpresionHandler);
  }
  configurarNavegacion();

  const toggle = document.getElementById("chatbotToggle");
  const panel = document.getElementById("chatbotPanel");
  const close = document.getElementById("chatbotClose");
  const send = document.getElementById("chatbotSend");
  const input = document.getElementById("chatbotInput");

  function togglePanel() {
    if (!panel) return;
    panel.classList.toggle("chatbot-panel-visible");
    if (panel.classList.contains("chatbot-panel-visible") && input) {
      input.focus();
    }
  }

  if (toggle) {
    toggle.addEventListener("click", togglePanel);
  }
  if (close) {
    close.addEventListener("click", togglePanel);
  }
  if (send && input) {
    send.addEventListener("click", () => {
      const texto = input.value.trim();
      if (!texto) return;
      enviarMensajeGridBot(texto);
      input.value = "";
      input.focus();
    });
    input.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        send.click();
      }
    });
  }

  inicializarChatbot();
});

const GRIDBOT_STORAGE_KEY = "gridbot_historial";

function agregarMensajeChat(tipo, contenido) {
  const contenedor = document.getElementById("chatbotMessages");
  if (!contenedor) return;
  const div = document.createElement("div");
  div.classList.add("chatbot-msg");
  if (tipo === "usuario") {
    div.classList.add("chatbot-msg-user");
  } else {
    div.classList.add("chatbot-msg-bot");
  }
  div.textContent = contenido;
  contenedor.appendChild(div);
  contenedor.scrollTop = contenedor.scrollHeight;

  const ahora = new Date().toISOString();
  const existente = JSON.parse(
    localStorage.getItem(GRIDBOT_STORAGE_KEY) || "[]"
  );
  existente.push({ tipo, contenido, fecha_hora: ahora });
  localStorage.setItem(GRIDBOT_STORAGE_KEY, JSON.stringify(existente));
}

function cargarHistorialChat() {
  const contenedor = document.getElementById("chatbotMessages");
  if (!contenedor) return;
  contenedor.innerHTML = "";
  const existente = JSON.parse(
    localStorage.getItem(GRIDBOT_STORAGE_KEY) || "[]"
  );
  existente.forEach((m) => {
    const div = document.createElement("div");
    div.classList.add("chatbot-msg");
    if (m.tipo === "usuario") {
      div.classList.add("chatbot-msg-user");
    } else {
      div.classList.add("chatbot-msg-bot");
    }
    div.textContent = m.contenido;
    contenedor.appendChild(div);
  });
  contenedor.scrollTop = contenedor.scrollHeight;
}

function respuestasPredefinidasGridBot(texto) {
  const t = texto.toLowerCase();
  if (t.includes("como inicio el analisis") || t.includes("¿cómo inicio el análisis")) {
    return "Para iniciar el análisis en esta versión web, usa la sección Inicio: ingresa colegio, proteína y peso, y pulsa en calcular. Más adelante se integrará la carga desde fotos y Excel.";
  }
  if (t.includes("indicador verde")) {
    return "El indicador verde suele representar que los resultados son correctos o están dentro del rango esperado. En el diseño final se documentará cada color y su interpretación.";
  }
  if (t.includes("modulo") && t.includes("deteccion")) {
    return "El módulo de detección se encargará de leer la información desde imágenes o archivos (por ejemplo, fotos de tablas o Excel) y convertirla en datos estructurados para el analizador.";
  }
  if (t.includes("base de datos")) {
    return "La base de datos del proyecto está pensada para guardar históricos de análisis, configuraciones y, de forma controlada, partes del historial del chatbot sin datos personales.";
  }
  if (t.includes("ia conversacional") || t.includes("chatbot")) {
    return "GridBot es un chatbot educativo integrado en el sitio web. Explica el funcionamiento del analizador, los módulos del proyecto y conceptos básicos de integración de IA en aplicaciones web.";
  }
  return null;
}

async function enviarMensajeIA(mensajeUsuario) {
  const promptBase = `Eres GridBot, un asistente educativo para un proyecto de análisis y gestión de datos. Responde solo sobre temas relacionados con este proyecto:
- Funcionamiento del analizador.
- Módulos de detección visual, almacenamiento y lógica de análisis.
- Conceptos de desarrollo web relacionados con este sitio.
- No respondas sobre juegos de casino, manipulación de plataformas externas ni temas no relacionados.
Mensaje del usuario: ${mensajeUsuario}`;

  try {
    const resp = await fetch(`${API_BASE}/api/bodega/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: promptBase })
    });
    if (!resp.ok) {
      throw new Error(`Error ${resp.status}`);
    }
    const data = await resp.json();
    if (data && data.reply) {
      agregarMensajeChat("bot", data.reply);
    } else {
      agregarMensajeChat(
        "bot",
        "Por ahora solo tengo respuestas educativas básicas sobre este proyecto."
      );
    }
  } catch (e) {
    console.error(e);
    agregarMensajeChat(
      "bot",
      "No se pudo contactar al servicio de GridBot en este momento. Intenta de nuevo más tarde."
    );
  }
}

async function enviarMensajeGridBot(mensajeUsuario) {
  agregarMensajeChat("usuario", mensajeUsuario);

  const respuestaRapida = respuestasPredefinidasGridBot(mensajeUsuario);
  if (respuestaRapida) {
    agregarMensajeChat("bot", respuestaRapida);
    return;
  }

  await enviarMensajeIA(mensajeUsuario);
}

function inicializarChatbot() {
  cargarHistorialChat();
}
